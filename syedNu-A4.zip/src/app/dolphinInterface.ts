export interface Dolphin{
    name: string;
    species:string;
    classification:string;
    appearance:string;
}