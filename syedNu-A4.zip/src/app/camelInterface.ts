export interface Camel{
    name: string;
    species:string;
    classification:string;
    appearance:string;
}